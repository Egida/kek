#pragma once

#define HTTP_SERVER "62.84.118.147"
#define HTTP_PORT 80

#define TFTP_SERVER "62.84.118.147"
